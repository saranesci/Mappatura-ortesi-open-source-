# STL files to print a left hand

They are just a symmetry from the right hand files, which is why the engraved numbers are also reversed. 